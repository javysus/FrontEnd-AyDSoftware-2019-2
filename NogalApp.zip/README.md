# Nogal Fase II
Proyecto para Análisis y Diseño de Software 2019-2

## Archivos
A continuación se muestran dos carpetas, una para el BackEnd del proyecto y otra para el FrontEnd. La carpeta para el BackEnd no tiene funcionalidad en este repositorio, debido a que se encuentra ya implementada en la aplicación de Heroku.

## Requisitos
Como prototipo, la ejecución se ha realizado directamente en el navegador, en nuestro caso con Chrome, y para evitar errores de CORS, abrimos nuestro navegador ejecutando lo siguiente 
"chrome.exe --user-data-dir="C://Chrome dev session" --disable-web-security"

## Ejecución

1. Ir a la carpeta /Nogal-FrontEnd/www 
2. Abrir index.html con el navegador
3. Interactuar con las historias de usuario implementadas 